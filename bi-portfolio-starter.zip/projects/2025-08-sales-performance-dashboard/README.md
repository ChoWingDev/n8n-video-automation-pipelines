# Sales Performance Dashboard (Tableau)

**Tags:** dashboard, tableau, retail, kpi  
**Tools:** Tableau, SQL (extracts), CSV (synthetic data)  
**Timeline:** 2025-08 | **Role:** BI Analyst

## 1) What this does
Interactive executive dashboard for **sales KPIs** (YoY growth, category mix, region drilldowns) with filters and highlights for top/bottom performers.

## 2) Key artifacts
- `/workbook/` — Tableau workbook (.twb/.twbx) placeholder
- `/screenshots/` — dashboard screenshots
- `/data/` — synthetic sample data (schema only)

## 3) Highlights
- Clear KPI tiles + drill-downs for store/region/category
- Ready for **Tableau Public** or server deployment
- Designed for fast weekly refresh

## 4) How to run
Open the workbook in Tableau Desktop or Tableau Public; repoint the extract to `/data/` as needed.
